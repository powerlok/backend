
1.0.7 / 2012-11-21 
==================

  * fix component.json

1.0.4 / 2012-11-15 
==================

  * update css-stringify

1.0.3 / 2012-09-01 
==================

  * add component support

0.0.1 / 2010-01-03
==================

  * Initial release
